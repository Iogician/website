%% AAE 33800 Final Project: Estimating Heat Transfer at High Altitudes

%% Initialization
clear
close all
%% Calculations

%% INTERPOLATION FUNCTION

function [property] = interpolate(T, column, table)
    T_all = table(:, 1) + 273.15;
    interest = table(:, column);
    property = interp1(T_all, interest, T, 'linear');
end

%% DYNAMICS MODEL

function [M, time_range, alt] = dynamicsModel(diameter, Cd, m_dry, m_prop, avg_thrust, burn_time)
    %% AAE 33800 Final Project: DYNAMICS MODEL FUNCTION
    %% FUNCTION DESCTIPTION: Calculates altitude, velocty, and acceleration for sounding rocket 
    %% INPUTS:
    %    diameter: Outer Diameter of rocket [m]
    %    Cd: Drag Coefficent 
    %    m_dry: Mass of rocket, excluding expendable mass of propellant [kg]
    %    m_prop: Mass of Propellant [kg]
    %    avg_thrust: Avgerage thrust of motor [N]
    %    burn_time: duration of propellant burn [N]
    
    %%
    cross_area = pi*diameter^2/4; % m^2
    
    %burn time range
    t_range_burn = linspace(0, burn_time, 10000)';
    dt = t_range_burn(2) - t_range_burn(1);
    
    %mass
    m_tot = m_dry + m_prop; %kg
    
    % avg mass flow rate
    m_dot = m_prop/burn_time; %kg/s
    
    % initiate varibles
    vel = zeros(size(t_range_burn)); %m/s
    alt = zeros(size(t_range_burn)); %m
    fd = zeros(size(t_range_burn)); %N
    M = zeros(size(t_range_burn)); 
    fg = 9.81*m_tot; % force of gravity at ground level [N]
    fnet = avg_thrust - fg;
    
    %% ____________________
    %% CALCULATIONS
    for i = 1:1:numel(t_range_burn)
        fnet(i+1) = avg_thrust - fg - fd(i);
        m_tot(i+1) = m_tot(i) - m_dot*dt;
        vel(i+1) = vel(i) + fnet(i)*dt/m_tot(i);
        [~, a,~ , ~] = atmosisa(alt(i));
        M(i+1) = abs(vel(i))/a;
        alt(i+1) = alt(i) + vel(i)*dt;
        [~, ~, ~, rho] = atmosisa(alt(i));
        fd(i+1) = Cd*cross_area*rho*vel(i)^2/2;
        if alt(i)<0
            fprintf('Not enough thrust for given specifications: Rocket Will Not Fly!\n')
            return
        end
    end
    
    % rocket coast until apex
    i = numel(t_range_burn)+1;
    while vel(i) > 0
        fnet(i+1) = -fg - fd(i);
        m_tot(i+1) = m_tot(i);
        vel(i+1) = vel(i) + fnet(i)*dt/m_tot(i);
        [~, a(i),~ , ~] = atmosisa(alt(i));
        M(i+1) = abs(vel(i))/a(i);
        alt(i+1) = alt(i)+vel(i)*dt;
        [~, ~, ~, rho] = atmosisa(alt(i));
        fd(i+1) = Cd*cross_area*rho*vel(i)^2/2;
        i = i + 1;
    end
    
    % rocket falling from max height
    while alt(i) > 0
        fnet(i+1) = fd(i) - fg; %drag force switches directions
        m_tot(i+1) = m_tot(i);
        vel(i+1) = vel(i) + fnet(i)*dt/m_tot(i);
        [~, a(i),~ , ~] = atmosisa(alt(i));
        M(i+1) = abs(vel(i))/a(i);
        alt(i+1) = alt(i)+vel(i)*dt;
        [~, ~, ~, rho] = atmosisa(alt(i));
        fd(i+1) = Cd*cross_area*rho*vel(i)^2/2;
        i = i + 1;
    end
    
    %total flight time
    tot_time = i*dt; 
    %total flight time range
    time_range = linspace(0, tot_time, i)';
    % max alititude
    apogee = max(alt)*3.281; %ft
    % max velocity
    max_vel = max(vel);
    max_M = max(M);
end

%% CASE STUDY CALCULATIONS

function calculations(caseNumber, k, rho_airframe, Cp_airframe, Cd, m_dry, m_prop, avgThrust, burnTime, D_outer, t, L, k_ins, rho_ins, Cp_ins, t_ins, desiredTemp)
    clc
    %% make sure input typing is correct
    k = str2double(k);
    rho_airframe = str2double(rho_airframe);
    Cp_airframe = str2double(Cp_airframe);
    Cd = str2double(Cd);
    m_dry = str2double(m_dry);
    m_prop = str2double(m_prop);
    avgThrust = str2double(avgThrust);
    burnTime = str2double(burnTime);
    D_outer = str2double(D_outer);
    t = str2double(t);
    L = str2double(L);
    flightType = "Rocket";
    k_ins = str2double(k_ins);
    rho_ins = str2double(rho_ins);
    Cp_ins = str2double(Cp_ins);
    t_ins = str2double(t_ins);
    desiredTemp = str2double(desiredTemp) + 237.15;
    %% input confirmation
    fprintf("INPUTS:\n----------------------------------------\n")
    fprintf("Case %d Analysis\n", caseNumber)
    fprintf("Airframe Thermal Conductivity (W/m·K): %.4f\n", k)
    fprintf("Airframe Outer Diameter (m): %.3f\n", D_outer)
    fprintf("Airframe Thickness (m): %.3f\n", t)
    fprintf("Airframe Length (m): %.3f\n", L)
    %% property table import
    airProperties = readmatrix('airproperties.csv', 'Range', 2);
    Cp_query = 2; % column index where Cp is located in property table
    k_air_query = 3; % column index where k is located in property table
    Pr_query = 4; % column index where Pr is located in property table
    %% calculations
    D_inner = D_outer - 2*t;
    [Ma, time, altitudes] = dynamicsModel(D_outer, Cd, m_dry, m_prop, avgThrust, burnTime);
    [T, a, P, rho, nu, mu] = atmosisa(altitudes);
    V = Ma .* a;
    flightTime = max(time);
    Ts_i = T(1) + 1;
    T_ins_i = Ts_i;
    Cp = interpolate(T, Cp_query, airProperties);
    k_air = interpolate(T, k_air_query, airProperties);
    Pr = interpolate(T, Pr_query, airProperties);    
    gamma = 1.4;
    T0 = T .* (1 + Ma.^2 * (gamma - 1) / 2);
    figure
    subplot(1, 3, 1)
    plot(time, altitudes, 'm-', 'LineWidth', 2)
    xlabel("Time (seconds)")
    ylabel("Altitude (m)")
    title(strcat("Trajectory of ", flightType))
    grid on
    subplot(1, 3, 2)
    [Xouter, Youter, Zouter] = cylinder(D_outer / 2, 100);
    [Xinner, Yinner, Zinner] = cylinder(D_inner / 2, 100);
    surf(Xouter + D_outer/2, Youter + D_outer/2, Zouter * L, 'FaceColor', [0.5 0.5 0.5],  'FaceAlpha',0.5,'EdgeColor','none')
    hold on
    surf(Xinner + D_outer/2, Yinner + D_outer/2, Zinner * L, 'FaceColor', [0.5 0.5 0.5], 'FaceAlpha',0.5,'EdgeColor','none')
    zlabel("Length of Airframe (m)")
    axis equal
    title(strcat("Geometry of ", flightType, " Airframe"))
    grid on    
    subplot(1, 3, 3)
    plot(time, V, 'b-', 'LineWidth', 2)
    xlabel("Time (seconds)")
    ylabel("Velocity (m/s)")
    title(strcat("Velocity of ", flightType))
    grid on    
    sgtitle(strcat("Basic ", flightType, " Parameters"))
    figure
    subplot(2, 2, 1)
    plot(altitudes, k_air, 'Color', "#D95319", 'LineWidth', 2)
    xlabel("Altitude (m)")
    ylabel("Thermal Conductivity (W/m·K)")
    grid on
    title("Thermal Conductivity vs. Altitude")
    subplot(2, 2, 2)
    plot(altitudes, Pr, 'm-', 'LineWidth', 2)
    xlabel("Altitude (m)")
    ylabel("Prandtl Number")
    grid on
    title("Prandtl Number vs. Altitude")    
    subplot(2, 2, 3)
    plot(altitudes, Cp, 'g-', 'LineWidth', 2)
    xlabel("Altitude (m)")
    ylabel("Specific Heat (J/kg·K)")
    grid on
    title("Specific Heat vs. Altitude") 
    subplot(2, 2, 4)
    plot(altitudes, T, 'r-', 'LineWidth', 2)
    xlabel("Altitude (m)")
    ylabel("Temperature (K)")
    grid on
    title("Temperature vs. Altitude")  
    sgtitle("Thermal Properties of Air at Varying Altitudes")
    Re = (abs(V) .* D_outer) ./ nu;
    Nu = 0.027 .* Re.^0.805 .* Pr.^(1/3);
    h = (Nu .* k_air) / D_outer;
    A_top = pi * (D_outer / 2)^2;
    SA = A_top + 2*pi*(D_outer / 2)*L;
    volume = pi * L * ((D_outer / 2)^2 - (D_inner / 2)^2) + pi*t*(D_inner / 2)^2;
    Lc = volume / SA;
    Bi = (h .* Lc) ./ k;
    fprintf("----------------------------------------\nCHECKPOINT PARAMETERS:\n----------------------------------------\n")
    fprintf("Maximum Biot Number: %.5f\nCross-Sectional Area: %.3f m^2\n", max(Bi), SA)
    Q = zeros(size(altitudes));
    Ts = zeros(size(Q));
    Q_ins = zeros(size(Q));
    T_ins = zeros(size(Ts));
    V_ins = ((D_inner / 2)^2 - ((D_inner - 2 * t_ins) / 2)^2) * L;
    A_ins = (SA - A_top) / 2;
    Ts(1) = Ts_i;
    T_ins(1) = T_ins_i;
    r = sqrt(Pr);
    T_wall = T + r .* (T0 - T);
    for j = 1:(length(altitudes) - 1)
        Q(j) = h(j) .* SA .* (Ts(j) - T(j));
        dt = time(j + 1) - time(j);
        lumpedConstant = (h(j) .* SA) ./ (rho_airframe .* volume .* Cp_airframe);
        dT = (lumpedConstant * (T(j) - Ts(j)) * dt);
        %fprintf("T = %.4f, V = %.4f, h = %.4f, k_air = %.4f, Nu = %.4f, Ts = %.4f, dT = %.4f, index: %d\n", T(j), V(j), h(j), k_air(j), Nu(j), Ts(j), dT, j)
        %pause(0.01)
        Ts(j + 1) = T_wall(j + 1) + dT;
        %fprintf("Surface Temperature: %.3f | delta T: %.3f | h = %.3f W/m^2-K\n", Ts, delta_T, h)
        Q_ins(j) = (k_ins * A_ins / t_ins) * (Ts(j + 1) - T_ins(j)) * dt;
        dT_ins = Q_ins(j) / (rho_ins * V_ins * Cp_ins);
        T_ins(j + 1) = T_ins(j) + dT_ins;
    end
    Q(length(altitudes)) = Q(length(altitudes) - 1);
    Ts_max = max(Ts);
    Q_max = max(Q);
    thicknesses = linspace(0, D_inner, length(T_ins))';
    T_ins_check = zeros(size(T_ins));
    for j = 1:(length(thicknesses))
        thickness = thicknesses(j);
        T_ins_check(j) = Ts_max - (Q_max * dt * thickness) / (k_ins * A_ins);
    end
    T_ins_check(T_ins_check < desiredTemp) = desiredTemp;
    figure
    totalPlots = 2;
    if caseNumber >= 2
        totalPlots = 3;
    end
    subplot(1, totalPlots, 1)
    plot(time, Q / SA, 'r-', 'LineWidth', 2)
    xlabel("Time (seconds)")
    ylabel("Heat Flux (W/m^2)")
    title("Heat Flux onto Airframe vs. Time")
    grid on
    subplot(1, totalPlots, 2)
    plot(time, Ts, 'k-', 'LineWidth', 2)
    hold on
    plot(time, T, 'b--', 'LineWidth', 2)
    xlabel("Time (seconds)")
    ylabel("Temperature (K)")
    title("Airframe Temperature vs. Time")
    grid on    
    legend("Surface Temperature", "Surrounding Temperature")
    sgtitle("Heating Characteristics of Rocket Throughout Flight")
    if totalPlots == 3
        subplot(1, totalPlots, totalPlots);
        if caseNumber == 2
            plot(time, T_ins, 'm-', 'LineWidth', 2)
            xlabel("Time (seconds)")
            ylabel("Temperature (K)")
            title("Insulation Temperature vs. Time")
            grid on    
        else
            plot(thicknesses, T_ins_check, 'c-', 'LineWidth', 2)
            hold on
            plot(thicknesses, linspace(desiredTemp, desiredTemp, length(thicknesses)), 'k--', 'LineWidth', 2)
            xlabel("Insulation Thickness (m)")
            ylabel("Internal Temperature (K)")
            title("Insulation Temperature at Various Thicknesses")
            legend("Variable Insulation Temperature", "Desired Internal Temperature")
            grid on    
        end
    end
end

%% User Inputs

function getInputs()
    f = figure('Position', [50, 100, 900, 800]);
    % k input
    vertPos = 750;
    buttons = 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Airframe Thermal Conductivity (W/m·K):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_k = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '237');
    % rho input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Airframe Density (kg/m^3):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_rho = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '2710');
    % cp input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Airframe Specific Heat (J/kg·K):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_Cp = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '470');    
    % drag coefficient input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Drag Coefficient:', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_Cd = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '0.1');
    % dry mass input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Dry Mass (kg):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_mdry = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '20');   
    % propellant mass input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Propellant Mass (kg):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_mprop = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '10');  
    % average thrust input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Average Thrust (N):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_avgthrust = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '10000');       
    % burn time input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Burn Time (s):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_burnTime = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '250');     
    % outer diameter input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Airframe Outer Diameter (m):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_D = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '1');
    % thickness input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Airframe Thickness (m):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_t = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '0.01');    
    % length input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Airframe Length (m):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_L = uicontrol('Style', 'edit', ...
                       'Position', [150, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '13'); 
    % case input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [50, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Simulation Case:', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);         
    dropdownOptions = {'Case 1', 'Case 2', 'Case 3'};
    hDropdown = uicontrol('Style', 'popupmenu', ...
                          'Position', [150, vertPos - (50 * (buttons - 1)), 100, 20], ...
                          'String', dropdownOptions, ...
                          'FontSize', 10);    
    % submit button
    buttons = buttons + 1;
    hButton = uicontrol('Style', 'pushbutton', ...
                        'Position', [405, vertPos - (50 * (buttons - 1)), 100, 30], ...
                        'String', 'Simulate', ...
                        'FontSize', 11, ...
                        'Callback', @onSubmit);
    % k of insulation input
    buttons = 1;
    uicontrol('Style', 'text', ...
              'Position', [325, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Insulation Thermal Conductivity (W/m·K):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_kins = uicontrol('Style', 'edit', ...
                       'Position', [425, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '0.032');   
    % rho of insulation input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [325, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Insulation Density (kg/m^3):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_rho_ins = uicontrol('Style', 'edit', ...
                       'Position', [425, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '2300');  
    % Cp of insulation input
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [325, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Insulation Specific Heat (J/kg·K):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_Cp_ins = uicontrol('Style', 'edit', ...
                       'Position', [425, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '1500');        
    % insulation thickness
    buttons = buttons + 1;
    uicontrol('Style', 'text', ...
              'Position', [325, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Insulation Thickness (m):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_tins = uicontrol('Style', 'edit', ...
                       'Position', [425, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10,'String', '0.1'); 
    % desired temperature input
    buttons = 1;
    uicontrol('Style', 'text', ...
              'Position', [600, vertPos - (50 * (buttons - 1)), 100, 20], ...
              'String', 'Desired Internal Temperature (°C):', ...
              'HorizontalAlignment', 'left', ...
              'FontSize', 6);

    hEdit_temp = uicontrol('Style', 'edit', ...
                       'Position', [700, vertPos - (50 * (buttons - 1)), 150, 25], ...
                       'FontSize', 10, 'String', '20');     
    function onSubmit(~, ~)
        k = get(hEdit_k, 'String');
        rho = get(hEdit_rho, 'String');
        Cp = get(hEdit_Cp, 'String');
        Cd  = get(hEdit_Cd, 'String');
        m_dry  = get(hEdit_mdry, 'String');
        m_prop  = get(hEdit_mprop, 'String');
        avgThrust  = get(hEdit_avgthrust, 'String');
        burnTime = get(hEdit_burnTime, 'String');
        D_outer = get(hEdit_D, 'String');
        t = get(hEdit_t, 'String');
        L = get(hEdit_L, 'String');  
        k_ins = get(hEdit_kins, 'String'); 
        rho_ins = get(hEdit_rho_ins, 'String'); 
        Cp_ins = get(hEdit_Cp_ins, 'String'); 
        t_ins = get(hEdit_tins, 'String'); 
        temp = get(hEdit_temp, 'String'); 
        caseNumber = get(hDropdown, 'Value');
        assignin('base', 'k', str2double(k));
        assignin('base', 'rho_airframe', str2double(rho));
        assignin('base', 'Cp_airframe', str2double(Cp));
        assignin('base', 'Cd', str2double(Cd));
        assignin('base', 'm_dry', str2double(m_dry));
        assignin('base', 'm_prop', str2double(m_prop));
        assignin('base', 'avgThrust', str2double(avgThrust));
        assignin('base', 'burnTime', str2double(burnTime));
        assignin('base', 'D_outer', str2double(D_outer));
        assignin('base', 't', str2double(t));
        assignin('base', 'L', str2double(L));
        assignin('base', 'k_ins', str2double(k_ins));
        assignin('base', 'rho_ins', str2double(rho_ins));
        assignin('base', 'Cp_ins', str2double(Cp_ins));
        assignin('base', 't_ins', str2double(t_ins));
        assignin('base', 'desiredTemp', str2double(temp));
        disp(caseNumber)
        assignin('base', 'caseNumber', caseNumber);
        close(f);
        calculations(caseNumber, k, rho, Cp, Cd, m_dry, m_prop, avgThrust, burnTime, D_outer, t, L, k_ins, rho_ins, Cp_ins, t_ins, temp);
    end
end

getInputs()